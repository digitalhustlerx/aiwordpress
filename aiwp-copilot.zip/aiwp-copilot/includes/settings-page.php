<?php
/**
 * Settings Page
 * 
 * Admin settings page with specialist selection
 */

if (!defined('ABSPATH')) {
    exit;
}

class AIWP_Settings_Page {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_settings_page'));
        add_action('admin_init', array($this, 'register_settings'));
    }
    
    /**
     * Add settings page
     */
    public function add_settings_page() {
        add_options_page(
            'AIWP Copilot Settings',
            'AIWP Copilot',
            'manage_options',
            'aiwp-copilot',
            array($this, 'render_settings_page')
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        // API Settings
        register_setting('aiwp_settings', 'aiwp_api_provider');
        register_setting('aiwp_settings', 'aiwp_api_key');
        register_setting('aiwp_settings', 'aiwp_api_endpoint');
        register_setting('aiwp_settings', 'aiwp_model');
        register_setting('aiwp_settings', 'aiwp_specialist');
        register_setting('aiwp_settings', 'aiwp_debug_mode');
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Handle form submission
        if (isset($_POST['aiwp_settings_submit'])) {
            check_admin_referer('aiwp_settings');
            
            update_option('aiwp_api_provider', sanitize_text_field($_POST['aiwp_api_provider']));
            update_option('aiwp_api_key', sanitize_text_field($_POST['aiwp_api_key']));
            update_option('aiwp_api_endpoint', esc_url_raw($_POST['aiwp_api_endpoint']));
            update_option('aiwp_model', sanitize_text_field($_POST['aiwp_model']));
            update_option('aiwp_specialist', sanitize_text_field($_POST['aiwp_specialist']));
            update_option('aiwp_debug_mode', isset($_POST['aiwp_debug_mode']) ? 1 : 0);
            
            echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
        }
        
        // Get current values
        $api_provider = get_option('aiwp_api_provider', 'openai');
        $api_key = get_option('aiwp_api_key', '');
        $api_endpoint = get_option('aiwp_api_endpoint', 'https://api.openai.com/v1');
        $model = get_option('aiwp_model', 'gpt-4o');
        $specialist = get_option('aiwp_specialist', 'default');
        $debug_mode = get_option('aiwp_debug_mode', false);
        
        // Get all specialists
        $specialists = AIWP_Specialist_Registry::get_all();
        
        ?>
        <div class="wrap">
            <h1>🚀 AIWP Copilot Settings</h1>
            <p>Configure your AI-powered WordPress content assistant with specialist modes.</p>
            
            <form method="post" action="">
                <?php wp_nonce_field('aiwp_settings'); ?>
                
                <table class="form-table">
                    
                    <!-- API Provider -->
                    <tr>
                        <th scope="row">
                            <label for="aiwp_api_provider">API Provider</label>
                        </th>
                        <td>
                            <select name="aiwp_api_provider" id="aiwp_api_provider" class="regular-text">
                                <option value="openai" <?php selected($api_provider, 'openai'); ?>>OpenAI</option>
                                <option value="groq" <?php selected($api_provider, 'groq'); ?>>Groq</option>
                            </select>
                            <p class="description">Select your AI provider.</p>
                        </td>
                    </tr>
                    
                    <!-- API Key -->
                    <tr>
                        <th scope="row">
                            <label for="aiwp_api_key">API Key</label>
                        </th>
                        <td>
                            <input type="password" 
                                   name="aiwp_api_key" 
                                   id="aiwp_api_key" 
                                   value="<?php echo esc_attr($api_key); ?>" 
                                   class="regular-text"
                                   placeholder="sk-...">
                            <p class="description">
                                Your API key. 
                                <a href="https://platform.openai.com/api-keys" target="_blank">Get OpenAI key</a> | 
                                <a href="https://console.groq.com/keys" target="_blank">Get Groq key</a>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- API Endpoint -->
                    <tr>
                        <th scope="row">
                            <label for="aiwp_api_endpoint">API Endpoint</label>
                        </th>
                        <td>
                            <input type="url" 
                                   name="aiwp_api_endpoint" 
                                   id="aiwp_api_endpoint" 
                                   value="<?php echo esc_attr($api_endpoint); ?>" 
                                   class="regular-text"
                                   placeholder="https://api.openai.com/v1">
                            <p class="description">
                                API endpoint URL.<br>
                                <strong>OpenAI:</strong> https://api.openai.com/v1<br>
                                <strong>Groq:</strong> https://api.groq.com/openai/v1
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Model -->
                    <tr>
                        <th scope="row">
                            <label for="aiwp_model">Model</label>
                        </th>
                        <td>
                            <input type="text" 
                                   name="aiwp_model" 
                                   id="aiwp_model" 
                                   value="<?php echo esc_attr($model); ?>" 
                                   class="regular-text"
                                   placeholder="gpt-4o">
                            <p class="description">
                                Model to use.<br>
                                <strong>OpenAI:</strong> gpt-4o, gpt-4o-mini, gpt-4-turbo<br>
                                <strong>Groq:</strong> llama-3.3-70b-versatile, mixtral-8x7b-32768
                            </p>
                        </td>
                    </tr>
                    
                    <!-- SPECIALIST SELECTOR -->
                    <tr style="border-top: 3px solid #2271b1;">
                        <th scope="row" colspan="2">
                            <h2 style="margin-top: 20px;">🎯 AI Specialist Mode</h2>
                            <p>Choose an AI specialist to optimize responses for specific tasks.</p>
                        </th>
                    </tr>
                    
                    <tr>
                        <th scope="row">
                            <label for="aiwp_specialist">Active Specialist</label>
                        </th>
                        <td>
                            <select name="aiwp_specialist" id="aiwp_specialist" class="regular-text" style="font-size: 16px; padding: 8px;">
                                <?php
                                // Group by tier
                                $tier1 = AIWP_Specialist_Registry::get_by_tier('tier1');
                                $tier2 = AIWP_Specialist_Registry::get_by_tier('tier2');
                                $default_specialist = AIWP_Specialist_Registry::get('default');
                                
                                // Default option
                                if ($default_specialist) {
                                    printf(
                                        '<option value="default" %s>%s %s</option>',
                                        selected($specialist, 'default', false),
                                        esc_html($default_specialist['icon']),
                                        esc_html($default_specialist['name'])
                                    );
                                }
                                
                                // Tier 1 specialists
                                if (!empty($tier1)) {
                                    echo '<optgroup label="━━━ ⭐ CORE SPECIALISTS ━━━">';
                                    foreach ($tier1 as $s) {
                                        printf(
                                            '<option value="%s" %s>%s %s</option>',
                                            esc_attr($s['id']),
                                            selected($specialist, $s['id'], false),
                                            esc_html($s['icon']),
                                            esc_html($s['name'])
                                        );
                                    }
                                    echo '</optgroup>';
                                }
                                
                                // Tier 2 specialists (Pro/Agency)
                                if (!empty($tier2)) {
                                    echo '<optgroup label="━━━ 💎 PRO SPECIALISTS (Coming Soon) ━━━">';
                                    foreach ($tier2 as $s) {
                                        printf(
                                            '<option value="%s" disabled>%s %s 🔒</option>',
                                            esc_attr($s['id']),
                                            esc_html($s['icon']),
                                            esc_html($s['name'])
                                        );
                                    }
                                    echo '</optgroup>';
                                }
                                ?>
                            </select>
                            
                            <div id="specialist-description" style="margin-top: 15px; padding: 15px; background: #f0f0f1; border-left: 4px solid #2271b1; display: none;">
                                <p style="margin: 0;"></p>
                            </div>
                            
                            <script>
                            jQuery(document).ready(function($) {
                                var specialists = <?php echo json_encode($specialists); ?>;
                                
                                function updateDescription() {
                                    var selectedId = $('#aiwp_specialist').val();
                                    var specialist = specialists[selectedId];
                                    
                                    if (specialist && specialist.description) {
                                        $('#specialist-description p').text(specialist.description);
                                        $('#specialist-description').slideDown();
                                    } else {
                                        $('#specialist-description').slideUp();
                                    }
                                }
                                
                                $('#aiwp_specialist').on('change', updateDescription);
                                updateDescription();
                            });
                            </script>
                            
                            <p class="description">
                                Each specialist has a custom system prompt optimized for specific tasks.<br>
                                <strong>🎨 Frontend Specialist:</strong> Modern UI/UX, Tailwind CSS, design systems<br>
                                <strong>📝 SEO Expert:</strong> Meta tags, schema markup, keyword optimization<br>
                                <strong>✍️ Copywriter (SaaS):</strong> Tech/startup voice, high-converting copy<br>
                                <strong>🛍️ Copywriter (E-commerce):</strong> Product descriptions, conversion copy
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Debug Mode -->
                    <tr style="border-top: 3px solid #2271b1;">
                        <th scope="row">
                            <label for="aiwp_debug_mode">Debug Mode</label>
                        </th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="aiwp_debug_mode" 
                                       id="aiwp_debug_mode" 
                                       value="1" 
                                       <?php checked($debug_mode, 1); ?>>
                                Enable debug logging
                            </label>
                            <p class="description">Logs API requests/responses to debug.log for troubleshooting.</p>
                        </td>
                    </tr>
                    
                </table>
                
                <p class="submit">
                    <input type="submit" 
                           name="aiwp_settings_submit" 
                           class="button button-primary" 
                           value="Save Settings">
                </p>
            </form>
            
            <!-- Quick Start Guide -->
            <div style="margin-top: 40px; padding: 20px; background: #fff; border: 1px solid #ccc;">
                <h2>🚀 Quick Start Guide</h2>
                
                <h3>1. Configure API</h3>
                <p>Enter your API key and endpoint above. For Groq (recommended for speed):</p>
                <ul>
                    <li><strong>Endpoint:</strong> https://api.groq.com/openai/v1</li>
                    <li><strong>Model:</strong> llama-3.3-70b-versatile</li>
                    <li><strong>API Key:</strong> Get from <a href="https://console.groq.com/keys" target="_blank">console.groq.com/keys</a></li>
                </ul>
                
                <h3>2. Choose a Specialist</h3>
                <p>Select an AI specialist mode above to optimize for:</p>
                <ul>
                    <li>🎨 <strong>Frontend Design</strong> - Beautiful, modern UI components</li>
                    <li>📝 <strong>SEO</strong> - Search-optimized content with meta tags</li>
                    <li>✍️ <strong>Copywriting</strong> - High-converting SaaS or E-commerce copy</li>
                </ul>
                
                <h3>3. Use in Editor</h3>
                <p>Open any post/page, and the AI Copilot widget will appear in the sidebar. Type your request and get specialist-optimized content!</p>
            </div>
        </div>
        <?php
    }
}
