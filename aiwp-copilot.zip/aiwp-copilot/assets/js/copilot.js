/**
 * AIWP Copilot - Main JavaScript
 * Version: 2.0.0
 */

(function($) {
    'use strict';
    
    const AIWPCopilot = {
        
        /**
         * Initialize
         */
        init: function() {
            this.createWidget();
            this.bindEvents();
            this.loadSpecialistInfo();
            
            if (window.aiwpCopilot.debugMode) {
                console.log('AIWP Copilot initialized');
                console.log('Active Specialist:', window.aiwpCopilot.specialistName);
            }
        },
        
        /**
         * Create widget
         */
        createWidget: function() {
            const widget = `
                <div id="aiwp-copilot-widget" class="aiwp-widget">
                    <div class="aiwp-header">
                        <h3>🤖 AI Copilot</h3>
                        <div id="aiwp-specialist-badge"></div>
                        <button class="aiwp-toggle" id="aiwp-toggle">−</button>
                    </div>
                    <div class="aiwp-body">
                        <div class="aiwp-messages" id="aiwp-messages"></div>
                        <div class="aiwp-input-container">
                            <textarea id="aiwp-prompt" 
                                      placeholder="Ask AI Copilot..."
                                      rows="3"></textarea>
                            <button id="aiwp-send" class="aiwp-send-btn">
                                <span class="dashicons dashicons-arrow-up-alt2"></span>
                                Send
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            $('body').append(widget);
            
            // Update specialist badge
            this.updateSpecialistBadge();
        },
        
        /**
         * Bind events
         */
        bindEvents: function() {
            const self = this;
            
            // Toggle widget
            $('#aiwp-toggle').on('click', function() {
                $('.aiwp-body').slideToggle();
                $(this).text($(this).text() === '−' ? '+' : '−');
            });
            
            // Send message
            $('#aiwp-send').on('click', function() {
                self.sendMessage();
            });
            
            // Enter to send (Shift+Enter for new line)
            $('#aiwp-prompt').on('keydown', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    self.sendMessage();
                }
            });
        },
        
        /**
         * Update specialist badge
         */
        updateSpecialistBadge: function() {
            if (window.aiwpCopilot.specialist === 'default') {
                $('#aiwp-specialist-badge').hide();
                return;
            }
            
            $('#aiwp-specialist-badge').html(
                `<div class="specialist-badge-active">
                    ${window.aiwpCopilot.specialistName}
                </div>`
            ).show();
        },
        
        /**
         * Load specialist info
         */
        loadSpecialistInfo: function() {
            if (window.aiwpCopilot.debugMode) {
                $.ajax({
                    url: window.aiwpCopilot.apiUrl + '/specialists',
                    method: 'GET',
                    headers: {
                        'X-WP-Nonce': window.aiwpCopilot.nonce
                    },
                    success: function(response) {
                        if (response.success) {
                            console.log('Available Specialists:', response.data);
                        }
                    }
                });
            }
        },
        
        /**
         * Send message
         */
        sendMessage: function() {
            const prompt = $('#aiwp-prompt').val().trim();
            
            if (!prompt) {
                return;
            }
            
            // Add user message
            this.addMessage('user', prompt);
            
            // Clear input
            $('#aiwp-prompt').val('');
            
            // Show loading
            this.addMessage('assistant', '...');
            const $loadingMsg = $('#aiwp-messages .aiwp-message:last');
            
            // Get current page context
            const postId = $('#post_ID').val() || null;
            
            // Prepare messages
            const messages = [
                {
                    role: 'user',
                    content: prompt
                }
            ];
            
            // Add page context if available
            if (postId) {
                messages.unshift({
                    role: 'system',
                    content: `You are helping edit WordPress post ID ${postId}. Current context will be provided.`
                });
            }
            
            // Send request
            $.ajax({
                url: window.aiwpCopilot.apiUrl + '/complete',
                method: 'POST',
                headers: {
                    'X-WP-Nonce': window.aiwpCopilot.nonce,
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    messages: messages,
                    options: {
                        temperature: 0.7,
                        max_tokens: 2000
                    }
                }),
                success: function(response) {
                    $loadingMsg.remove();
                    
                    if (response.success && response.data.choices && response.data.choices[0]) {
                        const content = response.data.choices[0].message.content;
                        AIWPCopilot.addMessage('assistant', content);
                    } else {
                        AIWPCopilot.addMessage('error', 'No response received');
                    }
                },
                error: function(xhr) {
                    $loadingMsg.remove();
                    
                    let errorMsg = 'An error occurred';
                    
                    if (xhr.responseJSON && xhr.responseJSON.error) {
                        errorMsg = xhr.responseJSON.error.message;
                    }
                    
                    AIWPCopilot.addMessage('error', errorMsg);
                }
            });
        },
        
        /**
         * Add message to chat
         */
        addMessage: function(role, content) {
            const $messages = $('#aiwp-messages');
            
            const className = role === 'user' ? 'aiwp-message-user' : 
                             role === 'error' ? 'aiwp-message-error' : 
                             'aiwp-message-assistant';
            
            const $message = $('<div>')
                .addClass('aiwp-message')
                .addClass(className)
                .html(this.formatContent(content));
            
            $messages.append($message);
            
            // Scroll to bottom
            $messages[0].scrollTop = $messages[0].scrollHeight;
        },
        
        /**
         * Format content (basic markdown support)
         */
        formatContent: function(content) {
            // Escape HTML
            content = $('<div>').text(content).html();
            
            // Basic markdown
            content = content.replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>');
            content = content.replace(/`([^`]+)`/g, '<code>$1</code>');
            content = content.replace(/\*\*([^\*]+)\*\*/g, '<strong>$1</strong>');
            content = content.replace(/\*([^\*]+)\*/g, '<em>$1</em>');
            content = content.replace(/\n/g, '<br>');
            
            return content;
        }
    };
    
    // Initialize when ready
    $(document).ready(function() {
        // Only initialize in post editor
        if ($('#post_ID').length || $('.block-editor').length) {
            AIWPCopilot.init();
        }
    });
    
})(jQuery);
